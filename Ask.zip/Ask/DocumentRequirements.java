package com.kyc.models;

import java.util.Set;
import java.util.HashSet;
import java.util.List;

/**
 * Document requirements based on customer category and risk level
 * Java 21 record with builder pattern support
 */
public record DocumentRequirements(
    Set<DocumentType> requiredCategories,
    Set<DocumentType> optionalCategories,
    int minimumDocuments,
    int maximumDocuments
) {
    
    public DocumentRequirements {
        if (requiredCategories == null) {
            requiredCategories = new HashSet<>();
        }
        if (optionalCategories == null) {
            optionalCategories = new HashSet<>();
        }
        if (minimumDocuments < 0) {
            throw new IllegalArgumentException("Minimum documents cannot be negative");
        }
        if (maximumDocuments < minimumDocuments) {
            throw new IllegalArgumentException("Maximum documents cannot be less than minimum");
        }
    }
    
    /**
     * Get all allowed categories (required + optional)
     */
    public Set<DocumentType> getAllowedCategories() {
        Set<DocumentType> allowed = new HashSet<>(requiredCategories);
        allowed.addAll(optionalCategories);
        return allowed;
    }
    
    /**
     * Check if a document type is required
     */
    public boolean isRequired(DocumentType type) {
        return requiredCategories.contains(type);
    }
    
    /**
     * Check if a document type is optional
     */
    public boolean isOptional(DocumentType type) {
        return optionalCategories.contains(type);
    }
    
    /**
     * Check if a document type is allowed (required or optional)
     */
    public boolean isAllowed(DocumentType type) {
        return requiredCategories.contains(type) || optionalCategories.contains(type);
    }
    
    @Override
    public String toString() {
        return String.format("DocumentRequirements[required=%s, optional=%s, min=%d, max=%d]", 
                           requiredCategories, optionalCategories, minimumDocuments, maximumDocuments);
    }
    
    /**
     * Builder for DocumentRequirements
     */
    public static Builder builder() {
        return new Builder();
    }
    
    public static class Builder {
        private Set<DocumentType> required = new HashSet<>();
        private Set<DocumentType> optional = new HashSet<>();
        private int minDocs = 1;
        private int maxDocs = 50;
        
        public Builder addRequired(DocumentType... types) {
            required.addAll(List.of(types));
            return this;
        }
        
        public Builder addOptional(DocumentType... types) {
            optional.addAll(List.of(types));
            return this;
        }
        
        public Builder minimumDocuments(int min) {
            this.minDocs = min;
            return this;
        }
        
        public Builder maximumDocuments(int max) {
            this.maxDocs = max;
            return this;
        }
        
        public DocumentRequirements build() {
            return new DocumentRequirements(
                new HashSet<>(required), 
                new HashSet<>(optional), 
                minDocs, 
                maxDocs
            );
        }
    }
}