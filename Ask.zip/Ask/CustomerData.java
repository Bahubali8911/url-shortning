package com.kyc.models;

/**
 * Customer data model representing information from Excel file
 * Java 21 record with validation
 */
public record CustomerData(
    String customerId,
    String category,
    String riskLevel,
    String name,
    String email
) {
    
    public CustomerData {
        // Compact constructor validation
        if (customerId == null || customerId.trim().isEmpty()) {
            throw new IllegalArgumentException("Customer ID cannot be null or empty");
        }
        if (category == null || category.trim().isEmpty()) {
            throw new IllegalArgumentException("Category cannot be null or empty");
        }
        if (riskLevel == null || riskLevel.trim().isEmpty()) {
            throw new IllegalArgumentException("Risk level cannot be null or empty");
        }
        
        // Normalize values
        customerId = customerId.trim().toUpperCase();
        category = category.trim().toUpperCase();
        riskLevel = riskLevel.trim().toUpperCase();
        
        // Validate category
        if (!isValidCategory(category)) {
            throw new IllegalArgumentException("Invalid category: " + category + 
                ". Must be one of: INDIVIDUAL, SME, CORPORATE, PEP");
        }
        
        // Validate risk level
        if (!isValidRiskLevel(riskLevel)) {
            throw new IllegalArgumentException("Invalid risk level: " + riskLevel + 
                ". Must be one of: LOW, MEDIUM, HIGH");
        }
    }
    
    private static boolean isValidCategory(String category) {
        return "INDIVIDUAL".equals(category) || "SME".equals(category) || 
               "CORPORATE".equals(category) || "PEP".equals(category);
    }
    
    private static boolean isValidRiskLevel(String riskLevel) {
        return "LOW".equals(riskLevel) || "MEDIUM".equals(riskLevel) || "HIGH".equals(riskLevel);
    }
    
    @Override
    public String toString() {
        return String.format("CustomerData[id=%s, category=%s, risk=%s, name=%s]", 
                           customerId, category, riskLevel, name);
    }
}