package com.kyc.agents;

import com.google.adk.agents.LlmAgent;
import com.google.adk.agents.InvocationContext;
import com.google.adk.tools.Annotations.Schema;
import com.google.adk.tools.FunctionTool;
import com.kyc.models.ClassificationResult;
import com.kyc.models.CustomerData;
import com.kyc.models.DocumentInfo;
import com.kyc.models.DocumentRequirements;
import com.kyc.models.DocumentType;
import com.google.genai.v1beta2.GenerateMessageRequest;
import com.google.genai.v1beta2.Generation;
import com.google.genai.v1beta2.GenerativeServiceClient;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Agent responsible for document classification using Gemini AI
 * Makes one API call per document with multimodal support
 */
public class DocumentClassifierAgent {
    private static final Logger logger = LoggerFactory.getLogger(DocumentClassifierAgent.class);
    
    private final String modelLocation;
    private static final FunctionTool classifyTool =
        FunctionTool.create(DocumentClassifierAgent.class, "classifyDocument");
    private static final ObjectMapper objectMapper = new ObjectMapper();

    public DocumentClassifierAgent(String modelLocation) {
        this.modelLocation = modelLocation;
        logger.info("DocumentClassifierAgent initialized with model: {}", modelLocation);
    }

    public LlmAgent getAgent() {
        return LlmAgent.builder()
            .name("document-classifier")
            .model(modelLocation)
            .instruction("""
                You are a KYC document classification expert.
                
                Classify the provided document file into one of the expected document types.
                Consider the customer profile context for accurate classification.
                
                Return a JSON response with these exact fields:
                {
                  "fileName": "original filename",
                  "detectedType": "one of the expected types",
                  "confidence": number between 0-100
                }
                
                Expected document types will be provided in the prompt.
                """)
            .tools(classifyTool)
            .outputKey("classification_result")
            .build();
    }

    @SuppressWarnings("unchecked")
    public static Map<String, Object> classifyDocument(
        @Schema(name = "ctx") InvocationContext ctx) throws Exception {
        
        logger.info("Starting document classification...");
        
        // Get session data
        CustomerData customer = (CustomerData) ctx.session().state().get("customer_data");
        DocumentRequirements requirements = (DocumentRequirements) ctx.session().state().get("document_requirements");
        List<DocumentInfo> docs = (List<DocumentInfo>) ctx.session().state().get("kyc_documents");
        
        if (docs == null || docs.isEmpty()) {
            throw new IllegalStateException("No documents available for classification");
        }

        // Process one document at a time
        DocumentInfo doc = docs.remove(0);
        logger.info("Classifying document: {} (size: {})", doc.fileName(), doc.getHumanReadableSize());

        try (GenerativeServiceClient client = GenerativeServiceClient.create()) {
            // Build context-aware prompt
            String expectedTypes = requirements.requiredCategories().stream()
                .map(DocumentType::name)
                .collect(Collectors.joining(", "));
                
            String prompt = String.format("""
                Customer Profile:
                - Category: %s
                - Risk Level: %s
                
                Expected Document Types: %s
                
                Document to classify: %s
                
                Please classify this document and return JSON with fileName, detectedType, and confidence.
                """, 
                customer.category(), 
                customer.riskLevel(), 
                expectedTypes,
                doc.fileName()
            );

            // Create request with document file
            GenerateMessageRequest request = GenerateMessageRequest.newBuilder()
                .setModel(((DocumentClassifierAgent) ctx.agent()).modelLocation)
                .addMessages(GenerateMessageRequest.Message.newBuilder()
                    .setContent(prompt)
                    .build())
                .putInputFiles(doc.fileName(), doc.content())  // Send raw file content
                .setTemperature(0.1f)  // Low temperature for consistent classification
                .build();

            // Call Gemini
            Generation response = client.generateMessage(request);
            String jsonResponse = response.getChoices(0).getMessage().getContent();
            
            logger.debug("Gemini response: {}", jsonResponse);

            // Parse JSON response
            JsonNode node = objectMapper.readTree(jsonResponse);
            String fileName = node.get("fileName").asText();
            String detectedType = node.get("detectedType").asText();
            int confidence = node.get("confidence").asInt();

            // Validate detected type
            boolean meetsRequirements = requirements.isAllowed(DocumentType.valueOf(detectedType));

            ClassificationResult result = new ClassificationResult(
                fileName, 
                detectedType, 
                confidence, 
                meetsRequirements, 
                jsonResponse
            );

            logger.info("Classification result: {} -> {} ({}% confidence)", 
                       fileName, detectedType, confidence);

            // Update session state
            ctx.session().state().put("classification_result", result);
            ctx.session().state().put("kyc_documents", docs);

            return Map.of(
                "status", "success",
                "classification", result,
                "documentsRemaining", docs.size()
            );

        } catch (Exception e) {
            logger.error("Error classifying document: {}", doc.fileName(), e);
            
            // Create fallback result
            ClassificationResult fallbackResult = new ClassificationResult(
                doc.fileName(),
                DocumentType.OTHER_KYC.name(),
                0,
                false,
                "Classification failed: " + e.getMessage()
            );
            
            ctx.session().state().put("classification_result", fallbackResult);
            ctx.session().state().put("kyc_documents", docs);
            
            return Map.of(
                "status", "error",
                "classification", fallbackResult,
                "error", e.getMessage()
            );
        }
    }
}