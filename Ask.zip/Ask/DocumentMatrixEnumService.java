package com.kyc.services;

import com.kyc.models.DocumentRequirements;
import com.kyc.models.DocumentType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.EnumSet;
import java.util.Set;

/**
 * Service that provides dynamic document requirements based on customer category and risk level
 * Implements the KYC document matrix using enums for type safety
 */
public class DocumentMatrixEnumService {
    private static final Logger logger = LoggerFactory.getLogger(DocumentMatrixEnumService.class);

    /**
     * Get document requirements for a given customer profile
     */
    public DocumentRequirements getRequirements(String category, String riskLevel) {
        logger.debug("Getting requirements for category: {}, risk: {}", category, riskLevel);
        
        DocumentRequirements requirements = switch (category.toUpperCase()) {
            case "INDIVIDUAL" -> getIndividualRequirements(riskLevel);
            case "SME"        -> getSMERequirements(riskLevel);
            case "CORPORATE"  -> getCorporateRequirements(riskLevel);
            case "PEP"        -> getPEPRequirements(riskLevel);
            default           -> getDefaultRequirements(riskLevel);
        };
        
        logger.info("Requirements for {} {} customer: {} required types, {}-{} documents", 
                   riskLevel, category, requirements.requiredCategories().size(), 
                   requirements.minimumDocuments(), requirements.maximumDocuments());
        
        return requirements;
    }

    private DocumentRequirements getIndividualRequirements(String riskLevel) {
        Set<DocumentType> base = EnumSet.of(DocumentType.IDENTITY_PROOF, DocumentType.ADDRESS_PROOF);
        return buildRequirements(base, riskLevel, false);
    }

    private DocumentRequirements getSMERequirements(String riskLevel) {
        Set<DocumentType> base = EnumSet.of(DocumentType.IDENTITY_PROOF, DocumentType.ADDRESS_PROOF);
        return buildRequirements(base, riskLevel, false);
    }

    private DocumentRequirements getCorporateRequirements(String riskLevel) {
        Set<DocumentType> base = EnumSet.of(
            DocumentType.IDENTITY_PROOF, 
            DocumentType.ADDRESS_PROOF, 
            DocumentType.BUSINESS_REGISTRATION
        );
        return buildRequirements(base, riskLevel, false);
    }

    private DocumentRequirements getPEPRequirements(String riskLevel) {
        Set<DocumentType> base = EnumSet.of(
            DocumentType.IDENTITY_PROOF, 
            DocumentType.ADDRESS_PROOF, 
            DocumentType.BUSINESS_REGISTRATION
        );
        return buildRequirements(base, riskLevel, true); // PEP flag for enhanced checks
    }

    private DocumentRequirements getDefaultRequirements(String riskLevel) {
        Set<DocumentType> base = EnumSet.of(DocumentType.IDENTITY_PROOF, DocumentType.ADDRESS_PROOF);
        return buildRequirements(base, riskLevel, false);
    }

    private DocumentRequirements buildRequirements(Set<DocumentType> baseRequired, String riskLevel, boolean isPEP) {
        var required = EnumSet.copyOf(baseRequired);
        var optional = EnumSet.noneOf(DocumentType.class);
        int min, max;

        switch (riskLevel.toUpperCase()) {
            case "LOW":
                // Low risk - basic requirements only
                optional.add(DocumentType.INCOME_PROOF);
                min = required.size() + 3;
                max = min + 2;
                break;
                
            case "MEDIUM":
                // Medium risk - add income and bank statements
                required.addAll(EnumSet.of(
                    DocumentType.INCOME_PROOF, 
                    DocumentType.BANK_STATEMENTS
                ));
                min = required.size() + 3;
                max = min + 3;
                break;
                
            case "HIGH":
                // High risk - comprehensive documentation
                required.addAll(EnumSet.of(
                    DocumentType.INCOME_PROOF,
                    DocumentType.BANK_STATEMENTS,
                    DocumentType.SOURCE_OF_WEALTH,
                    DocumentType.ADDITIONAL_VERIFICATION
                ));
                
                // Add enhanced due diligence for PEP high risk
                if (isPEP) {
                    required.add(DocumentType.EDD_ENHANCED_CHECKS);
                }
                
                min = required.size() + 2;
                max = min + 5;
                break;
                
            default:
                logger.warn("Unknown risk level: {}, using LOW risk defaults", riskLevel);
                optional.add(DocumentType.INCOME_PROOF);
                min = required.size() + 3;
                max = min + 2;
        }

        return new DocumentRequirements(required, optional, min, max);
    }
}