package com.kyc.models;

/**
 * Document classification result from Gemini AI
 * Java 21 record with validation and utility methods
 */
public record ClassificationResult(
    String fileName,
    String category,
    int confidence,
    boolean meetsRequirements,
    String notes
) {
    
    public ClassificationResult {
        if (fileName == null || fileName.trim().isEmpty()) {
            throw new IllegalArgumentException("File name cannot be null or empty");
        }
        if (category == null || category.trim().isEmpty()) {
            throw new IllegalArgumentException("Category cannot be null or empty");
        }
        if (confidence < 0 || confidence > 100) {
            throw new IllegalArgumentException("Confidence must be between 0 and 100");
        }
        if (notes == null) {
            notes = "";
        }
    }
    
    /**
     * Check if classification has high confidence (>=90%)
     */
    public boolean isHighConfidence() {
        return confidence >= 90;
    }
    
    /**
     * Check if classification has medium confidence (70-89%)
     */
    public boolean isMediumConfidence() {
        return confidence >= 70 && confidence < 90;
    }
    
    /**
     * Check if classification has low confidence (<70%)
     */
    public boolean isLowConfidence() {
        return confidence < 70;
    }
    
    /**
     * Get confidence level as string
     */
    public String getConfidenceLevel() {
        if (isHighConfidence()) return "HIGH";
        if (isMediumConfidence()) return "MEDIUM";
        return "LOW";
    }
    
    /**
     * Check if classification should be manually reviewed
     */
    public boolean requiresReview() {
        return isLowConfidence() || !meetsRequirements;
    }
    
    /**
     * Get the document type enum if valid
     */
    public DocumentType getDocumentType() {
        try {
            return DocumentType.valueOf(category.toUpperCase());
        } catch (IllegalArgumentException e) {
            return DocumentType.OTHER_KYC;
        }
    }
    
    @Override
    public String toString() {
        return String.format("ClassificationResult[file=%s, category=%s, confidence=%d%% (%s), meets=%s]", 
                           fileName, category, confidence, getConfidenceLevel(), meetsRequirements);
    }
}