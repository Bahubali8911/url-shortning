package com.kyc;

import com.google.adk.agents.InMemoryRunner;
import com.google.adk.agents.Session;
import com.kyc.agents.KYCOrchestratorAgent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Main application class for KYC Document Processing System
 * Supports model location via environment variable or system property
 */
public class KYCProcessorApp {
    private static final Logger logger = LoggerFactory.getLogger(KYCProcessorApp.class);
    
    public static void main(String[] args) throws Exception {
        logger.info("Starting KYC Document Processing System...");
        
        try {
            // Read Gemini model location from environment or system property
            String modelLocation = getModelLocation();
            logger.info("Using Gemini model: {}", modelLocation);
            
            // Initialize the orchestrator agent with model location
            KYCOrchestratorAgent.initModelLocation(modelLocation);
            
            // Create in-memory runner
            InMemoryRunner runner = new InMemoryRunner(KYCOrchestratorAgent.getRootAgent());
            
            // Create session
            Session session = runner.createSession();
            
            // Default Excel file path (can be parameterized)
            String excelFilePath = args.length > 0 ? args[0] : "src/main/resources/sample-data/customer-data.xlsx";
            logger.info("Processing Excel file: {}", excelFilePath);
            
            // Process KYC documents
            String prompt = "Process KYC documents for customer data in file: " + excelFilePath;
            String result = session.run(prompt);
            
            logger.info("KYC Processing completed successfully");
            logger.info("Result: {}", result);
            
        } catch (Exception e) {
            logger.error("Error during KYC processing", e);
            throw e;
        }
    }
    
    private static String getModelLocation() {
        // Check system property first
        String modelLocation = System.getProperty("gemini.model.location");
        
        // Fall back to environment variable
        if (modelLocation == null) {
            modelLocation = System.getenv("GEMINI_MODEL_LOCATION");
        }
        
        // Provide default for development
        if (modelLocation == null) {
            modelLocation = "projects/your-project/locations/us-central1/models/gemini-2.0-flash-001";
            logger.warn("Using default model location. Set GEMINI_MODEL_LOCATION environment variable or gemini.model.location system property");
        }
        
        if (modelLocation.contains("your-project")) {
            throw new IllegalStateException(
                "Please configure your actual Gemini model location via GEMINI_MODEL_LOCATION environment variable " +
                "or gemini.model.location system property"
            );
        }
        
        return modelLocation;
    }
}