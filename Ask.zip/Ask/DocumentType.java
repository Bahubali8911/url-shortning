package com.kyc.models;

/**
 * Enum representing all possible KYC document types
 * Used for dynamic document matrix based on customer category and risk level
 */
public enum DocumentType {
    IDENTITY_PROOF("Identity Proof Documents"),
    ADDRESS_PROOF("Address Proof Documents"),
    INCOME_PROOF("Income Proof Documents"),
    BANK_STATEMENTS("Bank Account Statements"),
    SOURCE_OF_WEALTH("Source of Wealth Documentation"),
    ADDITIONAL_VERIFICATION("Additional Verification Documents"),
    BUSINESS_REGISTRATION("Business Registration Documents"),
    EDD_ENHANCED_CHECKS("Enhanced Due Diligence Checks"),
    OTHER_KYC("Other KYC Documents");

    private final String description;

    DocumentType(String description) {
        this.description = description;
    }

    public String getDescription() {
        return description;
    }

    @Override
    public String toString() {
        return name() + " (" + description + ")";
    }
}