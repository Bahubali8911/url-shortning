package com.kyc.agents;

import com.google.adk.agents.BaseAgent;
import com.google.adk.agents.SequentialAgent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Main orchestrator agent that coordinates the entire KYC processing workflow
 * Uses SequentialAgent for deterministic processing order
 */
public class KYCOrchestratorAgent {
    private static final Logger logger = LoggerFactory.getLogger(KYCOrchestratorAgent.class);
    
    // Static agent for ADK Dev UI compatibility
    public static BaseAgent ROOT_AGENT;
    
    public static void initModelLocation(String modelLocation) {
        logger.info("Initializing KYC Orchestrator Agent with model: {}", modelLocation);
        
        ROOT_AGENT = SequentialAgent.builder()
            .name("kyc-orchestrator")
            .description("Main KYC document processing orchestrator")
            .subAgents(
                new ExcelReaderAgent().getAgent(),
                new DocumentFetcherAgent().getAgent(),
                new DocumentClassifierAgent(modelLocation).getAgent(),
                new FileProcessorAgent().getAgent()
            )
            .build();
            
        logger.info("KYC Orchestrator Agent initialized successfully");
    }
    
    public static BaseAgent getRootAgent() {
        if (ROOT_AGENT == null) {
            throw new IllegalStateException("Orchestrator agent not initialized. Call initModelLocation() first.");
        }
        return ROOT_AGENT;
    }
}