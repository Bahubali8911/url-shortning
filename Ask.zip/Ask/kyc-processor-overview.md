# KYC Document Processing System - Complete Implementation

## Project Structure
```
kyc-processor/
├── pom.xml
├── README.md
├── src/
│   ├── main/
│   │   ├── java/com/kyc/
│   │   │   ├── KYCProcessorApp.java
│   │   │   ├── agents/
│   │   │   │   ├── KYCOrchestratorAgent.java
│   │   │   │   ├── ExcelReaderAgent.java
│   │   │   │   ├── DocumentFetcherAgent.java
│   │   │   │   ├── DocumentClassifierAgent.java
│   │   │   │   └── FileProcessorAgent.java
│   │   │   ├── models/
│   │   │   │   ├── DocumentType.java
│   │   │   │   ├── CustomerData.java
│   │   │   │   ├── DocumentInfo.java
│   │   │   │   ├── DocumentRequirements.java
│   │   │   │   └── ClassificationResult.java
│   │   │   ├── services/
│   │   │   │   └── DocumentMatrixEnumService.java
│   │   │   └── utils/
│   │   │       ├── ExcelProcessor.java
│   │   │       ├── FileSystemUtils.java
│   │   │       └── ZipManager.java
│   │   └── resources/
│   │       ├── application.properties
│   │       └── sample-data/
│   │           ├── customer-data.xlsx
│   │           └── documents/
│   └── test/java/
└── .gitignore
```

## Quick Start

1. **Set Environment Variable:**
   ```bash
   export GEMINI_MODEL_LOCATION=projects/your-project/locations/us-central1/models/gemini-2.0-flash-001
   ```

2. **Build and Run:**
   ```bash
   mvn clean compile exec:java -Dexec.mainClass="com.kyc.KYCProcessorApp"
   ```

3. **Development UI:**
   ```bash
   mvn exec:java -Dexec.mainClass="com.google.adk.web.AdkWebServer"
   # Open: http://localhost:8080/dev-ui
   ```

## Features

- ✅ Java 21 with modern features (records, switch expressions)
- ✅ Google ADK 0.2.0 SequentialAgent workflow
- ✅ Gemini AI multimodal document classification
- ✅ Dynamic document matrix based on category/risk
- ✅ One API call per document for optimal processing
- ✅ Enterprise-ready error handling and logging
- ✅ Complete Maven build configuration

## Architecture

The system uses a deterministic SequentialAgent workflow:
1. **ExcelReaderAgent** - Reads customer profile from Excel
2. **DocumentFetcherAgent** - Fetches documents based on risk matrix  
3. **DocumentClassifierAgent** - Classifies each document with Gemini
4. **FileProcessorAgent** - Renames and zips classified documents

## Dynamic Document Matrix

| Category   | Risk   | Document Types Required | Count |
|------------|--------|------------------------|-------|
| Individual | Low    | IDENTITY_PROOF, ADDRESS_PROOF | 8-10 |
| Individual | Medium | + INCOME_PROOF, BANK_STATEMENTS | 12-15 |
| Individual | High   | + SOURCE_OF_WEALTH, ADDITIONAL_VERIFICATION | 15-18 |
| Corporate  | Low    | + BUSINESS_REGISTRATION | 15-18 |
| Corporate  | High   | + EDD_ENHANCED_CHECKS | 22-25 |
| PEP        | High   | Enhanced Due Diligence package | 25+ |

---

**All source code files are included below for easy download and setup.**