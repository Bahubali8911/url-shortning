package com.kyc.models;

import java.time.LocalDateTime;

/**
 * Document information model
 * Java 21 record representing document metadata and content
 */
public record DocumentInfo(
    String fileName,
    String filePath,
    String fileType,
    long fileSize,
    LocalDateTime lastModified,
    byte[] content
) {
    
    public DocumentInfo {
        if (fileName == null || fileName.trim().isEmpty()) {
            throw new IllegalArgumentException("File name cannot be null or empty");
        }
        if (filePath == null || filePath.trim().isEmpty()) {
            throw new IllegalArgumentException("File path cannot be null or empty");
        }
        if (content == null) {
            throw new IllegalArgumentException("File content cannot be null");
        }
        if (fileSize < 0) {
            throw new IllegalArgumentException("File size cannot be negative");
        }
    }
    
    /**
     * Get file extension from filename
     */
    public String getFileExtension() {
        int lastDotIndex = fileName.lastIndexOf('.');
        return lastDotIndex > 0 ? fileName.substring(lastDotIndex + 1).toLowerCase() : "";
    }
    
    /**
     * Check if file is a PDF
     */
    public boolean isPdf() {
        return "pdf".equalsIgnoreCase(getFileExtension()) || 
               "application/pdf".equalsIgnoreCase(fileType);
    }
    
    /**
     * Check if file is an image
     */
    public boolean isImage() {
        String ext = getFileExtension();
        return "jpg".equalsIgnoreCase(ext) || "jpeg".equalsIgnoreCase(ext) || 
               "png".equalsIgnoreCase(ext) || "gif".equalsIgnoreCase(ext) ||
               (fileType != null && fileType.startsWith("image/"));
    }
    
    /**
     * Get human readable file size
     */
    public String getHumanReadableSize() {
        if (fileSize < 1024) return fileSize + " B";
        if (fileSize < 1024 * 1024) return String.format("%.1f KB", fileSize / 1024.0);
        if (fileSize < 1024 * 1024 * 1024) return String.format("%.1f MB", fileSize / (1024.0 * 1024.0));
        return String.format("%.1f GB", fileSize / (1024.0 * 1024.0 * 1024.0));
    }
    
    @Override
    public String toString() {
        return String.format("DocumentInfo[name=%s, type=%s, size=%s]", 
                           fileName, fileType, getHumanReadableSize());
    }
}