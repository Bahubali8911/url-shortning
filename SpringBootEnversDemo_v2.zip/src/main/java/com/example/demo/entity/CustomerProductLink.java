
package com.example.demo.entity;

import org.hibernate.envers.Audited;
import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Audited
public class CustomerProductLink {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "customer_id")
    private Customer customer;

    @ManyToOne
    @JoinColumn(name = "product_id")
    private Product product;

    private String status; // e.g., PENDING, APPROVED, REJECTED
    private Long requestedBy;
    private LocalDateTime requestDate;
    private Long approvedBy;
    private LocalDateTime approvalDate;

    // Getters and setters
}
