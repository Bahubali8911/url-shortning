
package com.example.demo.entity;

import org.hibernate.envers.Audited;
import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;

@Entity
@Audited
public class Product {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private String description;

    @OneToMany(mappedBy = "product", cascade = CascadeType.ALL)
    private Set<CustomerProductLink> customerLinks = new HashSet<>();

    // Getters and setters
}
