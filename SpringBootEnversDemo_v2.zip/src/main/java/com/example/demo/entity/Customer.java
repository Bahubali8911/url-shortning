
package com.example.demo.entity;

import org.hibernate.envers.Audited;
import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;

@Entity
@Audited
public class Customer {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private String email;

    @OneToMany(mappedBy = "customer", cascade = CascadeType.ALL)
    private Set<CustomerProductLink> productLinks = new HashSet<>();

    // Getters and setters
}
