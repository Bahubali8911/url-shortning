-- Document Table
CREATE TABLE Document (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(255) NOT NULL,
    content TEXT,
    status ENUM('CREATE_REQUESTED', 'UPDATE_REQUESTED', 'APPROVED', 'REJECTED', 'NEW') NOT NULL,
    created_by BIGINT, -- User ID who created the document
    updated_by BIGINT, -- User ID who last updated the document
    approved_by BIGINT, -- User ID who approved the document
    created_date TIMESTAMP,
    updated_date TIMESTAMP,
    approved_date TIMESTAMP
);

-- User Table
CREATE TABLE User (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(100) NOT NULL,
    role VARCHAR(50), -- Role (e.g., "REQUESTER", "APPROVER")
    email VARCHAR(100)
);

-- Envers Revision Info Table
CREATE TABLE REVINFO (
    REV BIGINT PRIMARY KEY AUTO_INCREMENT, -- Unique revision ID
    REVTSTMP BIGINT -- Timestamp of the revision
);

-- Envers Document Audit Table
CREATE TABLE Document_AUD (
    id BIGINT, -- Document ID
    REV BIGINT, -- Revision ID (linking to Revision table)
    REVTYPE TINYINT, -- Operation type (ADD, MOD, DEL)
    name VARCHAR(255),
    content TEXT,
    status ENUM('CREATE_REQUESTED', 'UPDATE_REQUESTED', 'APPROVED', 'REJECTED', 'NEW'),
    created_by BIGINT,
    updated_by BIGINT,
    approved_by BIGINT,
    created_date TIMESTAMP,
    updated_date TIMESTAMP,
    approved_date TIMESTAMP,
    PRIMARY KEY (id, REV)
);
