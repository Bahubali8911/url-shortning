package com.example.documentapproval;

public enum DocumentStatus {
    CREATE_REQUESTED,
    UPDATE_REQUESTED,
    APPROVED,
    REJECTED,
    NEW
}
