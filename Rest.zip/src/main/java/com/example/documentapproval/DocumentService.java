package com.example.documentapproval;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;

@Service
public class DocumentService {
    @Autowired
    private DocumentRepository documentRepository;

    public Document createDocument(String name, String content, Long userId) {
        Document document = new Document();
        document.setName(name);
        document.setContent(content);
        document.setStatus(DocumentStatus.CREATE_REQUESTED);
        document.setCreatedBy(userId);
        document.setCreatedDate(LocalDateTime.now());
        return documentRepository.save(document);
    }

    public Document updateDocument(Long documentId, String content, Long userId) {
        Document document = documentRepository.findById(documentId).orElseThrow();
        document.setContent(content);
        document.setStatus(DocumentStatus.UPDATE_REQUESTED);
        document.setUpdatedBy(userId);
        document.setUpdatedDate(LocalDateTime.now());
        return documentRepository.save(document);
    }

    public Document approveDocument(Long documentId, Long approverId) {
        Document document = documentRepository.findById(documentId).orElseThrow();
        document.setStatus(DocumentStatus.APPROVED);
        document.setApprovedBy(approverId);
        document.setApprovedDate(LocalDateTime.now());
        return documentRepository.save(document);
    }

    public Document rejectDocument(Long documentId) {
        Document document = documentRepository.findById(documentId).orElseThrow();
        Document latestApprovedVersion = documentRepository.findLatestApprovedVersion(documentId);
        if (latestApprovedVersion != null) {
            document.setContent(latestApprovedVersion.getContent());
            document.setStatus(DocumentStatus.REJECTED);
        }
        return documentRepository.save(document);
    }
}
