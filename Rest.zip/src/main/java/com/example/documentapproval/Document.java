package com.example.documentapproval;
import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
public class Document {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private String content;

    @Enumerated(EnumType.STRING)
    private DocumentStatus status;

    private Long createdBy;
    private Long updatedBy;
    private Long approvedBy;

    private LocalDateTime createdDate;
    private LocalDateTime updatedDate;
    private LocalDateTime approvedDate;

    // Getters and Setters
}
