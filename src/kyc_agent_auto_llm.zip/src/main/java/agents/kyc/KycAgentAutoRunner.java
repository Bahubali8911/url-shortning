package agents.kyc;

import com.google.adk.runner.InMemoryRunner;
import com.google.adk.sessions.Session;
import com.google.genai.types.Content;
import com.google.genai.types.Part;
import io.reactivex.rxjava3.core.Flowable;

/**
 * Entry point for running the KYC LLM agent automatically with no user input.
 * This class creates an InMemoryRunner for the KycAgent.ROOT_AGENT, opens a
 * session, and sends a predefined instruction to the agent to process all
 * customers in the Excel file. The agent uses its registered tools to read
 * the Excel, fetch documents, classify them using Gemini, rename and zip
 * them, and output a summary. All outputs from the agent are printed to
 * the console. The workflow runs once and terminates without requiring
 * interactive input from a user.
 */
public class KycAgentAutoRunner {

    public static void main(String[] args) {
        // Create a runner for the root KYC agent
        InMemoryRunner runner = new InMemoryRunner(KycAgent.ROOT_AGENT);
        String userId = "auto-run";
        // Create a new session for this run
        Session session = runner.sessionService().createSession(KycAgent.ROOT_AGENT.getName(), userId).blockingGet();
        // Define a natural-language instruction telling the agent to process
        // all customers automatically. The LLM will decide to invoke the
        // registered tools (readExcel, fetchDocuments, classifyDocument,
        // renameAndZip) in the correct order.
        String instruction = "Process all customers in the Excel file for KYC. " +
                "For each customer, fetch the documents, classify them using the KYC classification tool, " +
                "rename and zip the files, and provide a JSON report. Do not ask any questions; " +
                "just execute the tasks and output the results.";
        Content userMessage = Content.fromParts(Part.fromText(instruction));
        // Run the agent asynchronously and print each event's content as it arrives
        Flowable<com.google.adk.events.Event> events = runner.runAsync(userId, session.id(), userMessage);
        events.blockingForEach(event -> {
            // Print only the agent's textual output
            System.out.println(event.stringifyContent());
        });
    }
}