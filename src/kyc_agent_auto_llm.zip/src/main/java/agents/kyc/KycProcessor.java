package agents.kyc;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Simple entry point for running the KYC workflow end‑to‑end with no
 * interactive input. This class reads all customers from the fixed Excel
 * file (data/customers.xlsx), fetches their documents, classifies them
 * using the real Gemini API (assuming a valid API key or service account
 * configuration is available), renames and zips the files, and outputs a
 * JSON report for each customer. It does not rely on the LLM agent at
 * runtime; instead it calls the tools directly.
 */
public class KycProcessor {

    public static void main(String[] args) {
        String excelPath = "data/customers.xlsx";
        File excelFile = new File(excelPath);
        if (!excelFile.exists()) {
            System.err.println("Excel file not found at " + excelPath);
            return;
        }
        List<CustomerInfo> customers = new ArrayList<>();
        // Read all customers from the Excel sheet
        try (FileInputStream fis = new FileInputStream(excelFile);
             Workbook workbook = new XSSFWorkbook(fis)) {
            Sheet sheet = workbook.getSheetAt(0);
            boolean header = true;
            for (Row row : sheet) {
                if (header) { header = false; continue; }
                String customerId = row.getCell(0).toString();
                String category = row.getCell(1).toString();
                String riskLevel = row.getCell(2).toString();
                if (customerId != null && !customerId.isBlank()) {
                    customers.add(new CustomerInfo(customerId.trim(), category.trim(), riskLevel.trim()));
                }
            }
        } catch (Exception e) {
            throw new RuntimeException("Failed to read customers: " + e.getMessage(), e);
        }
        if (customers.isEmpty()) {
            System.err.println("No customers found in the Excel file.");
            return;
        }
        // Process each customer sequentially
        for (CustomerInfo customer : customers) {
            System.out.println("\n=== Processing customer " + customer.customerId() + " (" + customer.category() + ", " + customer.riskLevel() + ") ===");
            // Determine expected document types for this customer's category and risk level
            List<String> expectedTypes = KycTools.getExpectedDocumentTypes(customer.category(), customer.riskLevel());
            KycTools.setCurrentExpectedTypes(expectedTypes);
            // Fetch document paths as a JSON string and parse it into a list
            Map<String,String> docsMap = KycTools.fetchDocuments(customer.customerId(), customer.category(), customer.riskLevel());
            String docsJson = docsMap.getOrDefault("documents", "[]");
            List<String> docs = parseJsonArray(docsJson);
            if (docs.isEmpty()) {
                System.out.println("No documents found for customer " + customer.customerId());
                KycTools.clearCurrentExpectedTypes();
                continue;
            }
            // Classify each document and collect details
            Map<String,String> classificationMap = new HashMap<>();
            List<Map<String,String>> details = new ArrayList<>();
            for (String path : docs) {
                Map<String,String> result = KycTools.classifyDocument(path);
                classificationMap.put(path, result.getOrDefault("type", "Unknown"));
                details.add(result);
                System.out.println("Classified " + path + " as " + result.get("type") +
                        " (confidence=" + result.get("confidence") + ", reason=" + result.get("reason") + ")");
            }
            // Compute mapping for new filenames (used for reporting only)
            Map<String,String> renamedMap = new HashMap<>();
            for (String path : docs) {
                String type = classificationMap.getOrDefault(path, "Unknown");
                String fileName = new File(path).getName();
                int idx = fileName.lastIndexOf('.');
                String ext = idx >= 0 ? fileName.substring(idx) : "";
                String newName = customer.customerId() + "_" + type + ext;
                renamedMap.put(path, newName);
            }
            // Rename and zip the files
            Map<String,String> zipResult = KycTools.renameAndZip(customer.customerId(), classificationMap);
            String zipPath = zipResult.get("zipPath");
            System.out.println("Created zip file: " + zipPath);
            // Build and output a JSON report
            String report = KycTools.buildJsonReport(renamedMap, details);
            System.out.println("Report for customer " + customer.customerId() + ":\n" + report);
            // Clear context for next customer
            KycTools.clearCurrentExpectedTypes();
        }
    }

    /**
     * Parses a JSON array string of strings (e.g. ["a","b","c"]) into a
     * list of plain Java strings. This simple parser assumes the JSON is
     * well‑formed and does not contain escaped quotes.
     */
    private static List<String> parseJsonArray(String json) {
        List<String> result = new ArrayList<>();
        String trimmed = json.trim();
        if (trimmed.length() < 2 || trimmed.charAt(0) != '[' || trimmed.charAt(trimmed.length() - 1) != ']') {
            return result;
        }
        // Remove the brackets and split on commas
        String body = trimmed.substring(1, trimmed.length() - 1);
        if (body.isBlank()) return result;
        String[] parts = body.split(",");
        for (String p : parts) {
            String s = p.trim();
            if (s.startsWith("\"") && s.endsWith("\"")) {
                s = s.substring(1, s.length() - 1);
            }
            // Unescape backslash and quotes
            s = s.replace("\\\"", "\"").replace("\\\\", "\\");
            result.add(s);
        }
        return result;
    }
}