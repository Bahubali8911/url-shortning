package agents.kyc;

import com.google.adk.tools.Annotations.Schema;
import com.google.genai.Client;
import com.google.genai.types.Content;
import com.google.genai.types.GenerateContentConfig;
import com.google.genai.types.GenerateContentResponse;
import com.google.genai.types.Part;
import org.apache.commons.io.FileUtils;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * Utility class housing the custom functions (tools) that will be exposed to the
 * LLM agent via FunctionTool. Each method is static and publicly accessible.
 */
public class KycTools {

    /**
     * Predefined mapping of expected document types keyed by customer category
     * and risk level. This map should be adjusted to reflect your real KYC
     * policies. For example, high‑risk individual customers require more
     * documents than low‑risk ones. Keys are stored in lowercase for ease of
     * lookup.
     */
    private static final Map<String, Map<String, List<String>>> PREDEFINED_DOCS = Map.of(
        "individual", Map.of(
            "high", List.of("Passport", "BankStatement", "UtilityBill", "Selfie"),
            "medium", List.of("Passport", "BankStatement", "UtilityBill"),
            "low", List.of("Passport", "BankStatement")
        ),
        "company", Map.of(
            "high", List.of("CompanyRegistration", "BankStatement", "AddressProof", "IncomeProof"),
            "medium", List.of("CompanyRegistration", "BankStatement", "AddressProof"),
            "low", List.of("CompanyRegistration", "BankStatement")
        )
    );

    /**
     * Returns the list of expected document types for a given customer category
     * and risk level. If the category or risk level is not found in the
     * predefined map, it returns an empty list. The keys are matched in
     * lower‑case to be case‑insensitive.
     *
     * @param category the customer category (e.g., Individual, Company)
     * @param riskLevel the risk level (e.g., High, Medium, Low)
     * @return list of expected document type names
     */
    public static List<String> getExpectedDocumentTypes(
            @Schema(name = "category", description = "Customer category") String category,
            @Schema(name = "riskLevel", description = "Risk level of the customer") String riskLevel) {
        if (category == null || riskLevel == null) return List.of();
        Map<String, List<String>> riskMap = PREDEFINED_DOCS.getOrDefault(category.toLowerCase(), Map.of());
        return riskMap.getOrDefault(riskLevel.toLowerCase(), List.of());
    }

    /**
     * Reads the given Excel file and returns a list of customer information
     * entries. This method expects the first sheet to have three columns in
     * order: CustomerID, Category, RiskLevel. The header row is skipped.
     *
     * @param excelPath absolute path to the Excel (.xlsx) file
     * @return list of CustomerInfo instances
     */
    public static Map<String, String> readExcel() {
        // Use a fixed location for the Excel file. In a real deployment this
        // might come from configuration rather than user input. The user
        // no longer needs to specify the path explicitly.
        String excelPath = "data/customers.xlsx";
        List<CustomerInfo> customers = new ArrayList<>();
        File file = new File(excelPath);
        if (!file.exists()) {
            throw new IllegalArgumentException("Excel file does not exist: " + excelPath);
        }
        try (FileInputStream fis = new FileInputStream(file);
             Workbook workbook = new XSSFWorkbook(fis)) {
            Sheet sheet = workbook.getSheetAt(0);
            boolean header = true;
            for (Row row : sheet) {
                // Skip header row
                if (header) {
                    header = false;
                    continue;
                }
                String customerId = getCellString(row, 0);
                String category = getCellString(row, 1);
                String riskLevel = getCellString(row, 2);
                if (customerId == null || customerId.isBlank()) continue;
                customers.add(new CustomerInfo(customerId.trim(), category.trim(), riskLevel.trim()));
            }
        } catch (IOException e) {
            throw new RuntimeException("Failed to read Excel file: " + e.getMessage(), e);
        }
        // Convert the list of customers to a JSON string
        StringBuilder sb = new StringBuilder();
        sb.append("[");
        boolean first = true;
        for (CustomerInfo c : customers) {
            if (!first) sb.append(",");
            first = false;
            sb.append("{\"customerId\":\"").append(escapeJson(c.customerId())).append("\",")
              .append("\"category\":\"").append(escapeJson(c.category())).append("\",")
              .append("\"riskLevel\":\"").append(escapeJson(c.riskLevel())).append("\"}");
        }
        sb.append("]");
        Map<String, String> result = new HashMap<>();
        result.put("customers", sb.toString());
        return result;
    }

    private static String getCellString(Row row, int index) {
        if (row.getCell(index) == null) return null;
        return row.getCell(index).toString();
    }

    /**
     * Given customer details, returns a list of document files that need to be
     * processed. For demonstration, this function reads all files under a
     * directory named after the customerId inside the project root's data folder.
     *
     * @param customerId the customer identifier
     * @param category   KYC category (unused in this demo but available for real logic)
     * @param riskLevel  risk level (unused in this demo but available for real logic)
     * @return list of absolute file paths representing the documents
     */
    public static Map<String, String> fetchDocuments(
            @Schema(name = "customerId", description = "Customer identifier") String customerId,
            @Schema(name = "category", description = "Customer category") String category,
            @Schema(name = "riskLevel", description = "Risk level of the customer") String riskLevel) {
        // Construct path to the customer's document directory
        Path dir = Path.of("data", customerId);
        List<String> docs = new ArrayList<>();
        if (Files.isDirectory(dir)) {
            try {
                Files.list(dir).filter(Files::isRegularFile).forEach(path -> docs.add(path.toAbsolutePath().toString()));
            } catch (IOException e) {
                throw new RuntimeException("Error listing documents for customer " + customerId + ": " + e.getMessage(), e);
            }
        }
        // Return the list as a JSON string within a map
        StringBuilder sb = new StringBuilder();
        sb.append("[");
        boolean first = true;
        for (String p : docs) {
            if (!first) sb.append(",");
            first = false;
            sb.append("\"").append(escapeJson(p)).append("\"");
        }
        sb.append("]");
        Map<String, String> result = new HashMap<>();
        result.put("documents", sb.toString());
        return result;
    }

    /**
     * Classifies a document by its filename and/or content. In a production
     * implementation this method could call out to a Gemini model via the ADK
     * LLM agent to perform document classification. For this proof‑of‑concept,
     * the classification is based on simple heuristics: if the filename
     * contains certain keywords it returns a corresponding type; otherwise
     * returns "Unknown". The method signature returns a map so the LLM can
     * return structured data.
     *
     * @param documentPath absolute path to the document file
     * @return a map containing the document type and original file path
     */
    public static Map<String, String> classifyDocument(
            @Schema(name = "documentPath", description = "Absolute path to the document to classify")
            String documentPath) {
        Map<String, String> result = new HashMap<>();
        result.put("originalPath", documentPath);
        // Default values when classification fails or no LLM is available
        String docType = "Unknown";
        String confidence = "0.0";
        String reason = "";

        // Attempt to classify via Gemini if an API key is available. If not,
        // fall back to filename heuristics. See the GenAI SDK documentation
        // demonstrating how to pass binary data using Part.fromBytes() in a
        // generateContent call【992318240269212†L141-L154】.
        String apiKey = System.getenv("GOOGLE_API_KEY");
        if (apiKey != null && !apiKey.isBlank()) {
            // If an API key is provided, use it (Developer API or Vertex Express Mode)
            try (Client client = Client.builder().apiKey(apiKey).build()) {
                // Read the document bytes. We assume PDFs for this POC, so set
                // the MIME type accordingly. If needed, use Files.probeContentType()
                // for other formats.
                byte[] bytes = Files.readAllBytes(Path.of(documentPath));
                Part filePart = Part.fromBytes(bytes, "application/pdf");
                // Construct a classification prompt. We instruct Gemini to return a
                // single line formatted as Category|Confidence|Reason so we can
                // easily parse it. We tailor the list of possible categories
                // based on the expected types context when available.
                String promptCategories;
                List<String> ctxTypes = CURRENT_EXPECTED_TYPES.get();
                if (ctxTypes != null && !ctxTypes.isEmpty()) {
                    promptCategories = String.join(", ", ctxTypes);
                } else {
                    promptCategories = String.join(", ", List.of(
                        "Passport", "IDCard", "DriverLicense", "BankStatement",
                        "UtilityBill", "Selfie", "AddressProof", "IncomeProof", "PANCard",
                        "VoterID", "ResidencePermit", "CompanyRegistration", "Other"
                    ));
                }
                Part promptPart = Part.fromText(
                    "You are a KYC document classification model. " +
                    "Possible categories include: " + promptCategories + ". " +
                    "Based solely on the document provided, return the best matching category, " +
                    "a confidence score between 0 and 1 indicating your certainty, and a brief reason for your choice. " +
                    "Separate the category, confidence, and reason with a '|' character. " +
                    "For example: Passport|0.85|Contains a passport photo and stamp. If you cannot classify the document, " +
                    "return Other|0.0|Not enough information."
                );
                // According to examples in the Gemini docs and blog posts, when sending
                // multimodal requests (e.g., a PDF and text prompt) the binary
                // document should be provided first followed by the text prompt in
                // the parts list【234242964365478†L186-L199】. If the prompt is
                // omitted or the file is provided after all text parts, the API
                // may complain that it "must have a text message". To avoid
                // this, send the file part first and then the prompt part.
                Content content = Content.fromParts(filePart, promptPart);
                // Build configuration. When using Vertex AI through a service account
                // the responseModalities must be explicitly set to TEXT to
                // indicate we expect text output【992318240269212†L141-L154】.
                GenerateContentConfig config = GenerateContentConfig.builder()
                        .candidateCount(1)
                        .responseModalities("TEXT")
                        .build();
                // Call Gemini to classify the document. We use the
                // gemini‑2.5‑flash model for its multimodal capabilities.
                GenerateContentResponse resp = client.models.generateContent(
                    "gemini-2.5-flash",
                    content,
                    config
                );
                String answer = resp.text() != null ? resp.text().trim() : "";
                if (answer != null && !answer.isEmpty()) {
                    // Split the answer on '|' and assign values accordingly
                    String[] parts = answer.split("\\|");
                    if (parts.length >= 1 && !parts[0].isEmpty()) docType = parts[0].trim();
                    if (parts.length >= 2 && !parts[1].isEmpty()) confidence = parts[1].trim();
                    if (parts.length >= 3) reason = parts[2].trim();
                }
            } catch (Exception ex) {
                // If anything goes wrong with the API call, fall back to heuristics.
                docType = fallbackHeuristic(documentPath);
                confidence = "0.0";
                reason = "Heuristic fallback";
            }
        } else {
            // No API key: attempt to use service account via Vertex AI
            try (Client client = buildClientUsingServiceAccount()) {
                // Read the document bytes
                byte[] bytes = Files.readAllBytes(Path.of(documentPath));
                Part filePart = Part.fromBytes(bytes, "application/pdf");
                Part promptPart = Part.fromText(
                    "You are a KYC document classification model. " +
                    "Possible categories include: Passport, IDCard, DriverLicense, BankStatement, " +
                    "UtilityBill, Selfie, AddressProof, IncomeProof, PANCard, VoterID, ResidencePermit, " +
                    "CompanyRegistration, Other. Based solely on the document provided, return the best matching category, " +
                    "a confidence score between 0 and 1 indicating your certainty, and a brief reason for your choice. " +
                    "Separate the category, confidence, and reason with a '|' character. " +
                    "For example: Passport|0.85|Contains a passport photo and stamp. If you cannot classify the document, " +
                    "return Other|0.0|Not enough information."
                );
                // Provide the file first then the prompt to satisfy the API's requirements
                Content content = Content.fromParts(filePart, promptPart);
                GenerateContentConfig config = GenerateContentConfig.builder()
                        .candidateCount(1)
                        .responseModalities("TEXT")
                        .build();
                GenerateContentResponse resp = client.models.generateContent(
                    "gemini-2.5-flash",
                    content,
                    config
                );
                String answer = resp.text() != null ? resp.text().trim() : "";
                if (answer != null && !answer.isEmpty()) {
                    String[] parts = answer.split("\\|");
                    if (parts.length >= 1 && !parts[0].isEmpty()) docType = parts[0].trim();
                    if (parts.length >= 2 && !parts[1].isEmpty()) confidence = parts[1].trim();
                    if (parts.length >= 3) reason = parts[2].trim();
                }
            } catch (Exception ex) {
                // Service account call failed; fall back to heuristics
                docType = fallbackHeuristic(documentPath);
                confidence = "0.0";
                reason = "Service account call failed; fallback heuristic used";
            }
        }
        result.put("type", docType);
        result.put("confidence", confidence);
        result.put("reason", reason);
        return result;
    }

    /**
     * Fallback heuristic classification based on the filename when the LLM call
     * is unavailable or fails. This replicates the previous simple logic.
     */
    private static String fallbackHeuristic(String documentPath) {
        File file = new File(documentPath);
        String fileName = file.getName().toLowerCase();
        if (fileName.contains("passport")) {
            return "Passport";
        } else if (fileName.contains("license")) {
            return "DriverLicense";
        } else if (fileName.contains("utility")) {
            return "UtilityBill";
        } else if (fileName.contains("bank")) {
            return "BankStatement";
        }
        return "Unknown";
    }

    /**
     * Renames documents based on their classification and zips them into a
     * single archive. This method expects a map where each entry's key is
     * the original document path and the value is the classification type. The
     * renamed files are stored under a temporary directory before being added
     * to the ZIP archive. The method returns the absolute path to the zip file.
     *
     * @param customerId         the customer identifier used for naming files
     * @param classificationMap  a map of original document paths to their classified type
     * @return absolute path to the created zip archive
     */
    public static Map<String, String> renameAndZip(
            @Schema(name = "customerId", description = "Customer identifier used when renaming files")
            String customerId,
            @Schema(name = "classificationMap", description = "Map of original document paths to their classified type")
            Map<String, String> classificationMap) {
        try {
            // Create a temporary directory to store renamed files
            Path tempDir = Files.createTempDirectory("kyc_renamed_");
            List<Path> renamedFiles = new ArrayList<>();
            for (Map.Entry<String, String> entry : classificationMap.entrySet()) {
                Path original = Path.of(entry.getKey());
                String type = entry.getValue();
                String newName = customerId + "_" + type + getExtension(original.getFileName().toString());
                Path dest = tempDir.resolve(newName);
                Files.copy(original, dest, StandardCopyOption.REPLACE_EXISTING);
                renamedFiles.add(dest);
            }
            // Create zip file
            Path zipPath = Files.createTempFile("kyc_documents_", ".zip");
            try (ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(zipPath.toFile()))) {
                for (Path path : renamedFiles) {
                    ZipEntry entry = new ZipEntry(path.getFileName().toString());
                    zos.putNextEntry(entry);
                    byte[] bytes = Files.readAllBytes(path);
                    zos.write(bytes, 0, bytes.length);
                    zos.closeEntry();
                }
            }
            // Cleanup temp directory
            FileUtils.deleteDirectory(tempDir.toFile());
            Map<String, String> result = new HashMap<>();
            result.put("zipPath", zipPath.toAbsolutePath().toString());
            return result;
        } catch (IOException e) {
            throw new RuntimeException("Failed to rename and zip documents: " + e.getMessage(), e);
        }
    }

    private static String getExtension(String filename) {
        int idx = filename.lastIndexOf('.');
        return idx >= 0 ? filename.substring(idx) : "";
    }

    /**
     * Constructs a JSON array string summarizing the classification results and
     * new filenames. Each entry in the array contains the original file
     * path, the new filename, the classified type, confidence score and the
     * model's reason. This is useful for returning structured output from
     * the overall workflow.
     *
     * @param renamedMap a map from original file path to new filename
     * @param details a list of classification detail maps returned by
     *                classifyDocument() (each map includes originalPath,
     *                type, confidence, reason)
     * @return a JSON string representing an array of result objects
     */
    public static String buildJsonReport(Map<String, String> renamedMap, List<Map<String, String>> details) {
        StringBuilder sb = new StringBuilder();
        sb.append("[");
        boolean first = true;
        for (Map<String, String> detail : details) {
            String original = detail.get("originalPath");
            String type = detail.getOrDefault("type", "Unknown");
            String confidence = detail.getOrDefault("confidence", "0.0");
            String reason = detail.getOrDefault("reason", "");
            String renamed = renamedMap.getOrDefault(original, "");
            if (!first) sb.append(",");
            first = false;
            sb.append("{\"originalPath\":\"").append(escapeJson(original)).append("\",");
            sb.append("\"renamedFile\":\"").append(escapeJson(renamed)).append("\",");
            sb.append("\"type\":\"").append(escapeJson(type)).append("\",");
            sb.append("\"confidence\":\"").append(escapeJson(confidence)).append("\",");
            sb.append("\"reason\":\"").append(escapeJson(reason)).append("\"}");
        }
        sb.append("]");
        return sb.toString();
    }

    // Helper to escape JSON special characters in a string
    private static String escapeJson(String input) {
        if (input == null) return "";
        return input.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n");
    }

    // Thread-local or static context for expected document types. This allows
    // callers to specify a subset of categories for the classification prompt.
    private static final ThreadLocal<List<String>> CURRENT_EXPECTED_TYPES = new ThreadLocal<>();

    /**
     * Sets the expected document types for the current thread. This list will
     * be used by the classifyDocument method to build a more specific
     * classification prompt. After finishing classification for a customer,
     * callers should clear this context by setting it to null or calling
     * clearCurrentExpectedTypes().
     */
    public static void setCurrentExpectedTypes(List<String> types) {
        CURRENT_EXPECTED_TYPES.set(types);
    }

    /**
     * Clears the expected document types context. Call this after finishing
     * classification for a customer to avoid leaking context across threads.
     */
    public static void clearCurrentExpectedTypes() {
        CURRENT_EXPECTED_TYPES.remove();
    }

    /**
     * Helper to build a Google GenAI client using service account credentials
     * for Vertex AI. It checks environment variables to determine whether
     * Vertex AI should be used. If `GOOGLE_GENAI_USE_VERTEXAI` is set to true,
     * the client is created with `vertexAI(true)`, pulling project and
     * location from `GOOGLE_CLOUD_PROJECT` and `GOOGLE_CLOUD_LOCATION`.
     * Otherwise, it falls back to a default client that will pick up
     * credentials via `GOOGLE_APPLICATION_CREDENTIALS` or other Google default
     * credential mechanisms. See the GenAI SDK documentation for details
     *【388047004191821†L300-L320】【486131544554251†L340-L389】.
     */
    private static Client buildClientUsingServiceAccount() {
        String useVertex = System.getenv("GOOGLE_GENAI_USE_VERTEXAI");
        if (useVertex != null && useVertex.equalsIgnoreCase("true")) {
            // Use Vertex AI backend; project and location come from env vars
            return Client.builder().vertexAI(true).build();
        }
        // Otherwise return a default client that uses application default credentials
        return new Client();
    }
}