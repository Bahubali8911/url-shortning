package agents.kyc;

/**
 * Simple record class to hold customer information read from the Excel sheet.
 */
public class CustomerInfo {
    private final String customerId;
    private final String category;
    private final String riskLevel;

    public CustomerInfo(String customerId, String category, String riskLevel) {
        this.customerId = customerId;
        this.category = category;
        this.riskLevel = riskLevel;
    }

    public String customerId() {
        return customerId;
    }

    public String category() {
        return category;
    }

    public String riskLevel() {
        return riskLevel;
    }

    @Override
    public String toString() {
        return "CustomerInfo{" +
               "customerId='" + customerId + '\'' +
               ", category='" + category + '\'' +
               ", riskLevel='" + riskLevel + '\'' +
               '}';
    }
}