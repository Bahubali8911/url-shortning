package agents.kyc;

import com.google.adk.agents.BaseAgent;
import com.google.adk.agents.LlmAgent;
import com.google.adk.runner.InMemoryRunner;
import com.google.adk.sessions.Session;
import com.google.adk.tools.FunctionTool;
import com.google.genai.types.Content;
import com.google.genai.types.Part;
import io.reactivex.rxjava3.core.Flowable;

import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

/**
 * Entry point for the KYC proof of concept. This class creates a single
 * LlmAgent with multiple tools that perform the steps required in the
 * workflow: reading the Excel file, fetching documents, classifying
 * documents and renaming/zipping them. While this agent exposes those tools
 * to an LLM, the {@code main()} method also demonstrates how to call
 * each tool in a standalone manner without invoking the LLM. This allows
 * the code to run locally even without a valid Gemini API key.
 */
public class KycAgent {

    private static final String NAME = "kyc_agent";
    private static final String USER_ID = "test-user";

    /**
     * Root agent configured with multiple function tools. In a real deployment
     * this agent could be prompted with natural language and would call the
     * appropriate tool based on the LLM's reasoning. Here we include the
     * definition for completeness.
     */
    public static final BaseAgent ROOT_AGENT = createAgent();

    private static BaseAgent createAgent() {
        return LlmAgent.builder()
                .name(NAME)
                // Specify Gemini model; if environment variables (GOOGLE_API_KEY etc.)
                // are set the agent can call Gemini. Otherwise the agent will run
                // offline and the tools can be invoked manually.
                .model("gemini-2.0-flash")
                .instruction("You are an agent that assists with KYC document processing. " +
                        "You can read Excel files to get customer info, fetch their documents, " +
                        "classify those documents, and rename/zip them.")
                .tools(
                        FunctionTool.create(KycTools.class, "readExcel"),
                        FunctionTool.create(KycTools.class, "fetchDocuments"),
                        FunctionTool.create(KycTools.class, "classifyDocument"),
                        FunctionTool.create(KycTools.class, "renameAndZip")
                )
                .build();
    }

    /**
     * Demonstrates using the tools without the LLM. The method reads a sample
     * Excel file, fetches customer documents from the data folder, classifies
     * each document and then renames/zips them. The paths to the Excel file
     * and documents are relative to the project root.
     */
    public static void main(String[] args) throws Exception {
        // The Excel file and documents are assumed to be located in the `data` folder.
        String excelPath = "data/customers.xlsx";
        // If the sample Excel file doesn't exist, create it with a single customer for the PoC.
        java.io.File excelFile = new java.io.File(excelPath);
        if (!excelFile.exists()) {
            excelFile.getParentFile().mkdirs();
            try (org.apache.poi.xssf.usermodel.XSSFWorkbook workbook = new org.apache.poi.xssf.usermodel.XSSFWorkbook()) {
                org.apache.poi.ss.usermodel.Sheet sheet = workbook.createSheet("Customers");
                org.apache.poi.ss.usermodel.Row header = sheet.createRow(0);
                header.createCell(0).setCellValue("CustomerID");
                header.createCell(1).setCellValue("Category");
                header.createCell(2).setCellValue("RiskLevel");
                org.apache.poi.ss.usermodel.Row row = sheet.createRow(1);
                row.createCell(0).setCellValue("12345");
                row.createCell(1).setCellValue("Individual");
                row.createCell(2).setCellValue("High");
                try (java.io.FileOutputStream fos = new java.io.FileOutputStream(excelFile)) {
                    workbook.write(fos);
                }
            }
        }
        // Step 1: Read customers from Excel
        List<CustomerInfo> customers = KycTools.readExcel(excelPath);
        if (customers.isEmpty()) {
            System.err.println("No customers found in the provided Excel file.");
            return;
        }
        // For the PoC we process the first customer only
        CustomerInfo customer = customers.get(0);
        System.out.println("Processing customer: " + customer);

        // Step 2: Ensure there are some sample documents for this customer
        java.nio.file.Path customerDir = java.nio.file.Path.of("data", customer.customerId());
        if (!java.nio.file.Files.isDirectory(customerDir)) {
            java.nio.file.Files.createDirectories(customerDir);
        }
        // Create simple placeholder files if none exist
        String[] sampleNames = {"passport.pdf", "license.jpg", "bank_statement.pdf", "utility_bill.pdf"};
        for (String name : sampleNames) {
            java.nio.file.Path filePath = customerDir.resolve(name);
            if (!java.nio.file.Files.exists(filePath)) {
                java.nio.file.Files.writeString(filePath, "Sample content for " + name);
            }
        }
        // Step 2: Fetch documents for this customer
        List<String> docs = KycTools.fetchDocuments(customer.customerId(), customer.category(), customer.riskLevel());
        if (docs.isEmpty()) {
            System.err.println("No documents found for customer " + customer.customerId());
            return;
        }
        System.out.println("Found " + docs.size() + " documents for customer " + customer.customerId());

        // Step 3: Classify each document using Gemini when available. We also
        // collect confidence scores and reasons for reporting.
        Map<String, String> typeMap = new HashMap<>();
        java.util.List<Map<String, String>> details = new java.util.ArrayList<>();
        for (String path : docs) {
            Map<String, String> result = KycTools.classifyDocument(path);
            // Record type for renaming
            typeMap.put(path, result.getOrDefault("type", "Unknown"));
            details.add(result);
            System.out.println("Classified " + path + " as " + result.get("type") + 
                    " (confidence=" + result.get("confidence") + ", reason=" + result.get("reason") + ")");
        }

        // Compute the new names for each document for reporting. The renaming
        // logic mirrors the one inside renameAndZip().
        Map<String, String> renamedMap = new HashMap<>();
        for (String path : docs) {
            String type = typeMap.get(path);
            String fileName = new java.io.File(path).getName();
            int idx = fileName.lastIndexOf('.');
            String ext = idx >= 0 ? fileName.substring(idx) : "";
            String newName = customer.customerId() + "_" + type + ext;
            renamedMap.put(path, newName);
        }

        // Step 4: Rename and zip documents
        String zipPath = KycTools.renameAndZip(customer.customerId(), typeMap);
        System.out.println("Renamed and zipped documents for customer " + customer.customerId() + ": " + zipPath);

        // Build and display a JSON report summarizing the results
        String reportJson = KycTools.buildJsonReport(renamedMap, details);
        System.out.println("Classification report:\n" + reportJson);

        // Optional: demonstrate interacting with the agent via LLM
        // Only runs if API key is available; otherwise will likely fail due to authentication.
        try (Scanner scanner = new Scanner(System.in, StandardCharsets.UTF_8)) {
            System.out.println("\nAgent demo. Type a request like 'Process KYC for customer " + customer.customerId() + "' or 'quit' to exit.");
            InMemoryRunner runner = new InMemoryRunner(ROOT_AGENT);
            Session session = runner.sessionService().createSession(NAME, USER_ID).blockingGet();
            while (true) {
                System.out.print("\nYou > ");
                String input = scanner.nextLine();
                if ("quit".equalsIgnoreCase(input)) {
                    break;
                }
                Content userMsg = Content.fromParts(Part.fromText(input));
                Flowable<com.google.adk.events.Event> events = runner.runAsync(USER_ID, session.id(), userMsg);
                System.out.print("\nAgent > ");
                events.blockingForEach(event -> System.out.println(event.stringifyContent()));
            }
        } catch (Exception e) {
            System.err.println("Agent interaction terminated: " + e.getMessage());
        }
    }
}